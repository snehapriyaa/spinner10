package abcd.com.contactsapp;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity {
    EditText fnametxt,phonenum,inputs;
    List<abcd.com.contactsapp.Contact> contacts = new ArrayList<abcd.com.contactsapp.Contact>();
    ImageView contactimgview;
    ListView contactlistview;
    Uri cimage=Uri.parse("android.resource://com.tallguylabs.practice/drawable/no_user_logo.png");




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fnametxt=(EditText)findViewById(R.id.editText1);
        phonenum=(EditText)findViewById(R.id.editText3);
        contactlistview=(ListView)findViewById(R.id.listView);
        contactimgview=(ImageView)findViewById(R.id.imageView);
        inputs=(EditText)findViewById(R.id.editText);
        TabHost tabhost=(TabHost)findViewById(R.id.tabHost);



        tabhost.setup();
        TabHost.TabSpec tabspec=tabhost.newTabSpec("creator");
        tabspec.setContent(R.id.contactcreator);
        tabspec.setIndicator("creator");
        tabhost.addTab(tabspec);
        tabspec=tabhost.newTabSpec("list");
        tabspec.setContent(R.id.contactlist);
        tabspec.setIndicator("list");
        tabhost.addTab(tabspec);
        final Button addbtn=(Button)findViewById(R.id.button);







        fnametxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                addbtn.setEnabled(!fnametxt.getText().toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }

        });



    }
    public void onActivityResult(int reqcode,int rescode, Intent data ){
        if(reqcode==RESULT_OK){
            if (rescode==1)
                cimage =(Uri)data.getData();
                contactimgview.setImageURI(data.getData());
        }
    }
    private void populatelist(){
        ArrayAdapter<Contact> adapter=new contactlistadapter();
        contactlistview.setAdapter(adapter);

    }







    private class contactlistadapter extends ArrayAdapter<abcd.com.contactsapp.Contact> {
        public contactlistadapter(){
            super(MainActivity.this, R.layout.listview_item, contacts);

        }
        public View getView(int position,View view,ViewGroup parent) {
            if (view == null)
                view = getLayoutInflater().inflate(R.layout.listview_item, parent, false);

            abcd.com.contactsapp.Contact currentcontact = contacts.get(position);

            TextView name = (TextView)view.findViewById(R.id.cname);
            name.setText(currentcontact.getname());
            TextView phone = (TextView)view.findViewById(R.id.phonenum);
            phone.setText(currentcontact.getphone());
             ImageView conimage = (ImageView)view.findViewById(R.id.imageView2);
            conimage.setImageURI(currentcontact.getimage());
            return view;

        }
    }
    public void add_contact(View view){
        contacts.add(new Contact(fnametxt.getText().toString(), phonenum.getText().toString(),cimage));
        populatelist();
        Toast.makeText(getApplicationContext(),fnametxt.getText().toString()+" is added to your contacts",Toast.LENGTH_SHORT).show();

    }
    public void add_photo(View view){
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(intent.ACTION_GET_CONTENT);
        startActivityForResult(intent.createChooser(intent,"select contact image"),1);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

